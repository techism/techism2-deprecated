# Unused dependency of base64 module
